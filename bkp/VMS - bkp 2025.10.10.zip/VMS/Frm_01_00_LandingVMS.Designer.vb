<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_01_00_LandingVMS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_01_00_LandingVMS))
        Logo_01 = New PictureBox()
        RibbonControlAdv1 = New Syncfusion.Windows.Forms.Tools.RibbonControlAdv()
        ToolStripTabItem1 = New Syncfusion.Windows.Forms.Tools.ToolStripTabItem()
        ToolStripTabItem2 = New Syncfusion.Windows.Forms.Tools.ToolStripTabItem()
        ToolStripTabItem3 = New Syncfusion.Windows.Forms.Tools.ToolStripTabItem()
        CType(Logo_01, ComponentModel.ISupportInitialize).BeginInit()
        CType(RibbonControlAdv1, ComponentModel.ISupportInitialize).BeginInit()
        RibbonControlAdv1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Logo_01
        ' 
        Logo_01.Location = New Point(307, 193)
        Logo_01.Name = "Logo_01"
        Logo_01.Size = New Size(300, 300)
        Logo_01.TabIndex = 2
        Logo_01.TabStop = False
        ' 
        ' RibbonControlAdv1
        ' 
        RibbonControlAdv1.BackStageNavigationButtonStyle = Syncfusion.Windows.Forms.Tools.BackStageNavigationButtonStyles.Office2013
        RibbonControlAdv1.Dock = Syncfusion.Windows.Forms.Tools.DockStyleEx.Top
        RibbonControlAdv1.Font = New Font("Calibri", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        RibbonControlAdv1.Header.AddMainItem(ToolStripTabItem1)
        RibbonControlAdv1.Header.AddMainItem(ToolStripTabItem2)
        RibbonControlAdv1.Header.AddMainItem(ToolStripTabItem3)
        RibbonControlAdv1.Location = New Point(0, 0)
        RibbonControlAdv1.MenuButtonFont = New Font("Calibri", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        RibbonControlAdv1.MenuButtonText = "File"
        RibbonControlAdv1.MenuButtonVisible = False
        RibbonControlAdv1.MenuButtonWidth = 56
        RibbonControlAdv1.MenuColor = Color.FromArgb(CByte(0), CByte(114), CByte(198))
        RibbonControlAdv1.Name = "RibbonControlAdv1"
        RibbonControlAdv1.OfficeColorScheme = Syncfusion.Windows.Forms.Tools.ToolStripEx.ColorScheme.Managed
        ' 
        ' RibbonControlAdv1.OfficeMenu
        ' 
        RibbonControlAdv1.OfficeMenu.Name = "OfficeMenu"
        RibbonControlAdv1.OfficeMenu.ShowItemToolTips = True
        RibbonControlAdv1.OfficeMenu.Size = New Size(12, 65)
        RibbonControlAdv1.QuickPanelImageLayout = PictureBoxSizeMode.StretchImage
        RibbonControlAdv1.RibbonHeaderImage = Syncfusion.Windows.Forms.Tools.RibbonHeaderImage.None
        RibbonControlAdv1.RibbonStyle = Syncfusion.Windows.Forms.Tools.RibbonStyle.Office2010
        RibbonControlAdv1.SelectedTab = ToolStripTabItem2
        RibbonControlAdv1.ShowRibbonDisplayOptionButton = True
        RibbonControlAdv1.Size = New Size(914, 140)
        RibbonControlAdv1.SystemText.QuickAccessDialogDropDownName = "Start menu"
        RibbonControlAdv1.SystemText.RenameDisplayLabelText = "&Display Name:"
        RibbonControlAdv1.TabIndex = 4
        RibbonControlAdv1.Text = "RibbonControlAdv1"
        RibbonControlAdv1.ThemeName = "Office2010"
        ' 
        ' ToolStripTabItem1
        ' 
        ToolStripTabItem1.Name = "ToolStripTabItem1"
        ' 
        ' RibbonControlAdv1.RibbonPanel1
        ' 
        ToolStripTabItem1.Panel.Name = "RibbonPanel1"
        ToolStripTabItem1.Panel.ScrollPosition = 0
        ToolStripTabItem1.Panel.TabIndex = 2
        ToolStripTabItem1.Panel.Text = "ToolStripTabItem1"
        ToolStripTabItem1.Position = 0
        ToolStripTabItem1.Size = New Size(140, 25)
        RibbonControlAdv1.TabGroups.SetTabGroup(ToolStripTabItem1, Nothing)
        ToolStripTabItem1.Tag = "1"
        ToolStripTabItem1.Text = "ToolStripTabItem1"
        ' 
        ' ToolStripTabItem2
        ' 
        ToolStripTabItem2.Name = "ToolStripTabItem2"
        ' 
        ' RibbonControlAdv1.RibbonPanel2
        ' 
        ToolStripTabItem2.Panel.Name = "RibbonPanel2"
        ToolStripTabItem2.Panel.ScrollPosition = 0
        ToolStripTabItem2.Panel.TabIndex = 3
        ToolStripTabItem2.Panel.Text = "ToolStripTabItem2"
        ToolStripTabItem2.Position = 1
        ToolStripTabItem2.Size = New Size(140, 25)
        RibbonControlAdv1.TabGroups.SetTabGroup(ToolStripTabItem2, Nothing)
        ToolStripTabItem2.Tag = "2"
        ToolStripTabItem2.Text = "ToolStripTabItem2"
        ' 
        ' ToolStripTabItem3
        ' 
        ToolStripTabItem3.Name = "ToolStripTabItem3"
        ' 
        ' RibbonControlAdv1.RibbonPanel3
        ' 
        ToolStripTabItem3.Panel.Name = "RibbonPanel3"
        ToolStripTabItem3.Panel.ScrollPosition = 0
        ToolStripTabItem3.Panel.TabIndex = 4
        ToolStripTabItem3.Panel.Text = "ToolStripTabItem3"
        ToolStripTabItem3.Position = 2
        ToolStripTabItem3.Size = New Size(140, 25)
        RibbonControlAdv1.TabGroups.SetTabGroup(ToolStripTabItem3, Nothing)
        ToolStripTabItem3.Tag = "3"
        ToolStripTabItem3.Text = "ToolStripTabItem3"
        ' 
        ' Frm_01_00_LandingVMS
        ' 
        AutoScaleDimensions = New SizeF(8F, 18F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(914, 540)
        Controls.Add(RibbonControlAdv1)
        Controls.Add(Logo_01)
        Font = New Font("Calibri", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        IsMdiContainer = True
        Margin = New Padding(3, 4, 3, 4)
        Name = "Frm_01_00_LandingVMS"
        Text = "VMS"
        CType(Logo_01, ComponentModel.ISupportInitialize).EndInit()
        CType(RibbonControlAdv1, ComponentModel.ISupportInitialize).EndInit()
        RibbonControlAdv1.ResumeLayout(False)
        RibbonControlAdv1.PerformLayout()
        ResumeLayout(False)
    End Sub
    Friend WithEvents Logo_01 As PictureBox
    Friend WithEvents RibbonControlAdv1 As Syncfusion.Windows.Forms.Tools.RibbonControlAdv
    Friend WithEvents ToolStripTabItem1 As Syncfusion.Windows.Forms.Tools.ToolStripTabItem
    Friend WithEvents ToolStripTabItem2 As Syncfusion.Windows.Forms.Tools.ToolStripTabItem
    Friend WithEvents ToolStripTabItem3 As Syncfusion.Windows.Forms.Tools.ToolStripTabItem
End Class

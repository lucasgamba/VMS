'BrandModel class added by the syncfusion
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace VMS '- vb.net

    Public Class BrandModel

        Public Property Year As String

        Public Property Value As Double

        Public Property Direction As String

        Public Property Tree As Double

    End Class

End Namespace
